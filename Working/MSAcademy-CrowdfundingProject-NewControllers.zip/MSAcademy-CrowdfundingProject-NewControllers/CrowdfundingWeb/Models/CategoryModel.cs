﻿using CrowdFundingProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrowdfundingWeb.Models
{
    public class CategoryModel
    {
        List<Tag> Tags { get; set; }
    }
}
