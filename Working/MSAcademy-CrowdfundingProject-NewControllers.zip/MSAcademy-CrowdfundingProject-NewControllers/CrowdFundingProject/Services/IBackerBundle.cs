using CrowdFundingProject.Models;

namespace CrowdFundingProject.Services
{
    public class IBackerBundle
    {
    }
}