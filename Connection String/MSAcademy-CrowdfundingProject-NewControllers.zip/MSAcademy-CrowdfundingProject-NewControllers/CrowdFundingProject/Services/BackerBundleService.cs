using CrowdFundingProject.Data;

namespace CrowdFundingProject.Services
{
    public class BackerBundleService
    {
        private readonly AppDbContext dbContext = new AppDbContext();
        
       

    }
}